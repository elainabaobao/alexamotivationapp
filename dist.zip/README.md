# alexa motivation app

-set up time and day alexa will say the motivation

-select a motivation theme

-once alexa speaks motivation you have to confirm

-if no confirmation you get a text message to confirm you recieved the motivation
