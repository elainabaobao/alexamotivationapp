const config = {
    alexaSkillId: 'amzn1.ask.skill.e1079dea-62fb-4b96-b90b-00f11f0beeed',
}



module.exports = config;
