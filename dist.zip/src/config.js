const config = {
    alexaSkillId: 'XXXXXXXXXXXXXXXXXX',
}

module.exports = config;
