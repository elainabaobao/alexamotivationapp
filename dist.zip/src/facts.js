const facts = {
	"themes": {
		"space": [

		],
		"physics": [
			{
				factName: "if you are sitting on opposite ends of a simple canoe with a partner, and you know the weight of the canoe and your own weight, then you can calculate how much your partner weights if you measure the displacement of the canoe as you and your partner get up and switch places."
			}
		]
	}
};

module.exports = facts;