const {init} = require('./src');

exports.handler = init;


